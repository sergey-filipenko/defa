var currentLanguage = 'sv';
var formSubmitSuccessMessage = 'Thanks for the message, be sure to print out your form before you go.';
var formSubmitErrorMessage = 'Form not saved.';
var formIsNotCompletedMessage =  'Please, complete the form';
var captchaCalculatorErrorMessage =  'Please Type valid value';